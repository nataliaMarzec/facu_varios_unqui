express = require("express");
bodyParser = require("body-parser");
const rsqlMongoDB = require('rsql-mongodb');
var cors = require('cors');
log = require("./src/logger");
swaggerJSDoc=require('swagger-jsdoc');
swaggerUi=require('swagger-ui-express');


var homes = {}

const swaggerDefinition =require("./swagger.json");
const API_PORT = process.env.API_PORT || 8888;


const options ={
  swaggerDefinition , apis: ['home'],
};
const swaggerSpec= swaggerJSDoc(options);


function register(home) {
  console.log(`registering handlers for ${home.type}`)
  homes[home.type] = home 
}

function init() {
  var server = express();
  server.use(bodyParser.json());

  //Funcion middleware para loggear los requests como info, este es de ejemplo y puede sacarse o cambiaar el nivel del log, ej, debug
  server.use((req, res, next) => {
      log.info(req.url)
      next()
  })

  server.use((err, req, res, next) => {
    log.error(err)
    next()
  })

server.use('/api-docs',swaggerUi.serve, swaggerUi.setup(swaggerSpec));



  server.use("(/:type/*)|(/:type)", (req, res, next) => {
      if (!homes[req.params.type]) {
        log.error(`home de ${req.params.type} no existe` );  
        res.status(404).end()
      }
      else {
        log.info(` home de ${req.params.type} si existe ` );
        next()
      }
  })

  server.use(cors())



 server.get("/:type/", (req, res) => {
    home = homes[req.params.type]
    home.get(req.params.id, (myObject) => { 
      res.json(myObject) 
      res.end() })  
  })


  server.get("/:type/:id", (req, res) => {
    home = homes[req.params.type]
    home.get(req.params.id, (myObject) => { 
      res.json(myObject) 
      res.end() })  
  })
  
  server.get("/:type", (req, res) => {
    var query = {}
    
    if (req.query.consulta) {
        console.log("Query:" + req.query.consulta) 
        var Consulta = (req.query.consulta)
        query = rsqlMongoDB (Consulta)
    } 
    home = homes[req.params.type]

    home.find(query,
      (allObjects) => {
        res.json(allObjects) 
        res.end()
      })         
  })
  

  server.put("/:type/", (req, res) => {
    home = homes[req.params.type]
    home.update(req.body)
    res.status(204).end();  
  })

  server.post("/:type/", (req, res) => {
    home = homes[req.params.type]
    home.insert(req.body)
    res.status(204).end();  
  })



  server.delete("/:type/:id", (req, res) => {
    home = homes[req.params.type]
    home.delete(req.params.id)
    res.status(204).end();  
  });

  server.listen(API_PORT, () => {
    console.log(`Server running on port ${API_PORT}`);
  });
}

exports.init = init;
exports.register = register;

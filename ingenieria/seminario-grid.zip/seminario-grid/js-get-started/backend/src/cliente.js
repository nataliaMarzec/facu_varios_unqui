class Cliente {

    constructor(nombre, direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
    }
}

module.exports = Cliente;
const winston = require('winston')
const consoleTransport = new winston.transports.Console()
const { combine, timestamp, printf } = winston.format;

const myFormat = printf(({ level, message, timestamp }) => {
    return `${timestamp} ${level}: ${message}`;
  });

const myWinstonOptions = {
    format: combine(
        timestamp(),
        myFormat
      ),
    level: 'debug',
    transports: [consoleTransport,
        new winston.transports.File({ filename: 'error.log', level: 'error' }),
        new winston.transports.File({ filename: 'info.log', level: 'info' }),
        new winston.transports.File({ filename: 'combined.log' })
    ]
}
const logger = new winston.createLogger(myWinstonOptions)

module.exports = logger
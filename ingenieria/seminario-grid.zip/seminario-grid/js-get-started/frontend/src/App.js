import React from 'react';
import logo from './logo.svg';
import EntityList from './components/EntityList'
import HomeComponent from './components/HomeComponent'
import Productos from './components/Productos'
import NavBar from "./components/NavBar";
import { useAuth0 } from "./react-auth0-wrapper";
import {BrowserRouter as Router, Route, Switch, Redirect, NavLink} from "react-router-dom"
import './App.css';
import ProductosGrid from './components/grid/ProductosGrid'
import ProductosColumsRisingGrid from './components/grid/ProductosColumsRisingGrid'
import OrdenarGrid from './components/grid/OrdenarColumnaGrid.js'
import ProductosBasicFilteringGrid from './components/grid/ProductosBasicFilteringGrid'


function App() {
  const { loading } = useAuth0();

  if (loading) {
    return (
      <div>Loading...</div>
    );
  }

  return (
    <div className="App">
      <Router>
        <header className="App-header">
          <NavBar/>
          <img src={logo} className="App-logo" alt="logo" />
            <ul>
              <li><NavLink to="/">Home</NavLink></li>
              <li><NavLink to="/clientes">Clientes</NavLink></li>
              <li><NavLink to="/productos">Productos</NavLink></li>
              <li><NavLink to="/productosDetails">ProductosDetails</NavLink></li>
              <li><NavLink to="/productosGrid">ProductosGrid</NavLink></li>
              <li><NavLink to="/productosColumsRisingGrid">ProductosColumsRisingGrid</NavLink></li>
              <li><NavLink to="/ordenarGrid">Ordenar Productos</NavLink></li>
              <li><NavLink to="/productosBasicFilteringGrid">ProductosBasicFilteringGrid</NavLink></li>
              <li><NavLink to="/gridFull">Grid Full </NavLink></li>
            </ul>
        </header>
        <main className="App-main">
           <Switch>
             <Route path="/" exact component={HomeComponent} />
             <Route path="/clientes"  component={ClientesComponent} />
             <Route path="/productos" component={ProductosComponent} />
             <Route path="/productosDetails" component={Productos} />
             <Route path="/productosGrid" component={ProductosGrid} />
             <Route path="/productosColumsRisingGrid" component={ProductosColumsRisingGrid} />
             <Route path="/ordenarGrid" component={OrdenarGrid}/>
             <Route path="/productosBasicFilteringGrid" component={ProductosBasicFilteringGrid}/>
             <Route path="/ordenarGrid" component={OrdenarGrid}/>
             <Redirect to="/" />

           </Switch>
       </main>
      </Router>
    </div>
  );
}


 function ClientesComponent() {
   return (<EntityList entity="clientes"/>)
 }

function ProductosComponent()  {
  return (<EntityList entity="productos"/>)
}

export default App;

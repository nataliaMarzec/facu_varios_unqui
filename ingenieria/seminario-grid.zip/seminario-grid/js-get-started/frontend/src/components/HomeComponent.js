import React from 'react';

class HomeComponent extends React.Component {

    render() {
      return (
        <div>
          <h1>
            Aplicación para manejar clientes y productos
          </h1>
        </div>
      );
    }
  }



  export default HomeComponent
  

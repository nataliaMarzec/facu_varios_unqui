import React from 'react';
//import ProductoRow from './ProductoRow';
import ReactDataGrid from 'react-data-grid';
import ProductoForm from '../ProductoForm';
import { Toolbar, Data } from "react-data-grid-addons";


class GridFull extends React.Component {
    constructor(props) {
    super(props);
    this.state = { productos: [], selected:{}}
    this.select = this.select.bind(this);
    this.productoChange = this.productoChange.bind(this);
  }

    componentWillMount() {
        fetch(`http://localhost:8888/productos`)
            .then( res => res.json())
            .then( prds => this.setState({productos: prds, initialRows: [...prds]})); // [...array] clona el array
    }
    render() {
     if( this.state.productos.length > 0 ) {
        const filteredRows = getRows(this.state.productos, this.state.filters);
        return(
            <div className="productosCSS">
                <h2>{this.props.titulo}</h2>     
                <ReactDataGrid
                    columns={this.columns()}
                    rowGetter={i => filteredRows[i]}
                    rowsCount={this.state.productos.length}
                    minHeight={150}
                    onGridSort={(sortColumn, sortDirection) =>
                    this.setState({productos: sortProducts(this.state.productos, sortColumn, sortDirection, this.state.initialRows)})} 
                    toolbar={<Toolbar enableFilter={true} />}
                    onAddFilter={filter => this.setState({filters: handleFilterChange(filter, this.state.filters)})}
                    onClearFilters={() => this.setState({filters: {}})}    
                    columnGetter={this.columns.length}
                    onColumnResize={(columnGetter,width) =>
                    console.log(`Column ${columnGetter} has been resized to ${width}`)} 
                />
                <ProductoForm producto={this.state.selected} productoChange={this.productoChange}/> 
          </div> 
        );
        }
    else {
        return(
            <div className="productosCSS">
                <h2>{this.props.titulo}</h2>
                CARGANDO
            </div>);  
    }
}
    select(unProducto) {
        this.setState({selected:unProducto })
    }

    productoChange(unProducto) {
        var newProductos = this.state.productos.map((item) => (unProducto._id !== item._id) ? item : unProducto )
        this.setState({productos: newProductos, selected:unProducto})
    }

    columns() {
      return [
        { key: '_id', 
        name: 'ID',
        sortDescendingFirst: true 
        },
        { key: 'nombre', 
        name: 'Nombre' 
        },
        { key: 'precio', 
        name: 'Precio' 
        } ].map(c=>({...c,...defaultColumnProperties}));
    }
  
}
    const handleFilterChange = (filter, filters) => {
        const newFilters = { ...filters };
        if (filter.filterTerm) {
            newFilters[filter.column.key] = filter;
        } else {
            delete newFilters[filter.column.key];
        }
        return newFilters;
    };
  
    function getRows(rows, filters) {
        return selectors.getRows({ rows, filters });
    }
  
    const defaultColumnProperties= {
        sortable:true,
        filterable: true,
        resizable: true
    };

    const selectors = Data.Selectors;   

    const sortProducts = (rows, sortColumn, sortDirection, initialRows) => {
        console.log(initialRows);
        const comparer = (a, b) => {
        if (sortDirection === "ASC") {
            if (typeof a[sortColumn] === 'string') {
                return a[sortColumn].toUpperCase() > b[sortColumn].toUpperCase() ? 1 : -1;
            } 
            else {
                if(typeof a[sortColumn] == 'number') {
                    return a[sortColumn] > b[sortColumn] ? 1 : -1;
                }
            }  
        } else{
            if (sortDirection === "DESC") {
                if (typeof a[sortColumn] === 'string') {
                    return a[sortColumn].toUpperCase() < b[sortColumn].toUpperCase() ? 1 : -1;
                } 
                else {
                    if(typeof a[sortColumn] === 'number'){                                    
                        return a[sortColumn] < b[sortColumn] ? 1 : -1;
                    }
                }
            }
        }  
        };
        return sortDirection === "NONE" ? [...initialRows] : rows.sort(comparer);
    };
    
  export default GridFull
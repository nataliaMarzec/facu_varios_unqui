import React from 'react';
import ReactDataGrid from "react-data-grid";
import ProductoForm from '../ProductoForm';
import { Toolbar, Data } from "react-data-grid-addons";

class ProductosBasicFilteringGrid extends React.Component {
    constructor(props) {
      super(props);
      this.state = { productos: [], selected:{}, filters:[] }
      this.select = this.select.bind(this);
      this.productoChange = this.productoChange.bind(this);
       
    }
  
    componentWillMount() {
      fetch(`http://localhost:8888/productos`)
        .then( res => res.json())
        .then( prds => this.setState({productos: prds}));
    }
   
    render() { 
        if( this.state.productos.length > 0 ) {
        const filteredRows = getRows(this.state.productos, this.state.filters);
        return (
            <div className="productosCSS">
            <h2>{this.props.titulo}</h2>

            <ReactDataGrid
              columns={this.columns()}
              rowGetter={i => filteredRows[i]}
              rowsCount={filteredRows.length}
              minHeight={500}
              toolbar={<Toolbar enableFilter={true} />}
              onAddFilter={filter => this.setState({filters: handleFilterChange(filter, this.state.filters)})}
              onClearFilters={() => this.setState({filters: {}})}/>
            <ProductoForm producto={this.state.selected} productoChange={this.productoChange} /> 
          </div> 
          );
        }
          else {
              return(
                <div className="productosCSS">
                    <h2>{this.props.titulo}</h2>
                    CARGANDO
                </div>);  
            }
      
          }
      
          select(unProducto) {
              this.setState({selected:unProducto })
            }
        
          productoChange(unProducto) {
              var newProductos = this.state.productos.map((item) => (unProducto._id !== item._id) ? item : unProducto )
              this.setState({productos: newProductos, selected:unProducto})
            }
  
          columns() {
              return [
                { key: '_id', name: 'ID' },
                { key: 'nombre', name: 'Nombre' },
                { key: 'precio', name: 'precio' }
              ].map(c => ({ ...c, ...defaultColumnProperties}));
                            
          }
    
        }
        

        const handleFilterChange = (filter, filters) => {
            const newFilters = { ...filters };
            if (filter.filterTerm) {
              newFilters[filter.column.key] = filter;
            } else {
              delete newFilters[filter.column.key];
            }
            return newFilters;
          };
          
          function getRows(rows, filters) {
            return selectors.getRows({ rows, filters });
          }
          

        const defaultColumnProperties= {
            filterable: true
        };

        const selectors = Data.Selectors;

    export default ProductosBasicFilteringGrid
  
  
   
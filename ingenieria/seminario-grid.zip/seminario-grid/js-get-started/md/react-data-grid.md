# Reac Data Grid
Es un componente de cuadrícula de datos similar a Excel desarrollado por React.

**Instalación:**
```
npm install react-data-grid --save
```

**Importamos el componente DataGrid**
```javascript
import React from 'react';
import ReactDataGrid from 'react-data-grid';
```
*Realizamos las distintas implementaciones realizando los cambios necesarios sobre el archivo Producto.js para obtener los distintos ejemplos de React-DataGrid, por cada implementación creamos su correspondiente archivo*

***Ejemplo para convertir nuestra tabla de productos en un grid:***
* En el render reemplazamos la tabla por un componente de ReactDataGrid que en este caso nos va a mostrar una "rejilla" tipo excel.

```javascript
 render() {
            ......
            <ReactDataGrid
                  columns={this.columns()}
                  rowGetter={i => this.state.productos[i]}
                  rowsCount={this.state.productos.length}
                  minHeight={150} />
            .....
     }
    ...........
    }

    columns() {
      return [
        { key: '_id', name: 'ID' },
        { key: 'nombre', name: 'Nombre' },
        { key: 'precio', name: 'Precio' } ];
    }
    
 
-Reemplazamos el renderRows:
    renderRows() {
       return this.state.productos.map((unProducto, index) => {
         return (
           <ProductoRow producto={unProducto} selector={this.select} />
         );
       })
     }
-por la siguiente lambda expresión:
    rowGetter={i => this.state.productos[i]}

```
***Ejemplo para cambiar el tamaño de las columnas***

```javaScript
    render() {
       ...

            <ReactDataGrid
            //..idem a los atributos de la rejilla simple...
                onColumnResize={(columnGetter,width) =>
                console.log(`Column ${columnGetter} has been resized to ${width}`)}/>
            ... 
          );
        }
        ...
        }
   
    columns() {
        return [
            { key: '_id', name: 'ID' },
            { key: 'nombre', name: 'Nombre' },
            { key: 'precio', name: 'precio' }
            ].map(c => ({ ...c, ...defaultColumnProperties}));
       }
 
    const defaultColumnProperties= {
        resizable: true,
        //Para poder cambiar el tamaño de una columna determinada
        width: 120
      };

```


***Ejemplo para realizar un filtrado por columnas***

Importamos el componente :
```javaScript
import { Toolbar, Data } from "react-data-grid-addons";

En el render agregamos una constante y el componente DataGrid
render() { 
        ...
        const filteredRows = getRows(this.state.productos, this.state.filters);
        return (
         ...
            <ReactDataGrid
              //..idem a los atributos de la rejilla simple...
              toolbar={<Toolbar enableFilter={true} />}
              onAddFilter={filter => this.setState({filters: handleFilterChange(filter, this.state.filters)})}
              onClearFilters={() => this.setState({filters: {}})
              //limpia los filtros
              }/>
            ...
          );
        }
          ...
          }
      
    columns() {
        return [
            { key: '_id', name: 'ID' },
            { key: 'nombre', name: 'Nombre' },
            { key: 'precio', name: 'precio' }
            ].map(c => ({ ...c, ...defaultColumnProperties}));
             }
        }
    const defaultColumnProperties= {
            filterable: true
        };
        // Para hacer que una columna sea filtrable

    const handleFilterChange = (filter, filters) => {
            const newFilters = { ...filters };
            if (filter.filterTerm) {
              newFilters[filter.column.key] = filter;
            } else {
              delete newFilters[filter.column.key];
            }
            return newFilters;
          };
          
    function getRows(rows, filters) {
        return selectors.getRows({ rows, filters });
          }  
        //Los selectores son funciones que se utilizan para seleccionar un subconjunto de datos de una colección de datos más grande. El selector permite una mayor eficiencia al representar los datos. En lugar de volver a calcular cuáles son las filas filtradas para cada render de cuadrícula, el selector solo vuelve a calcular las filas cuando cambian las entradas.    
       
    const selectors = Data.Selectors;
```

***Ejemplo para ordenar las columnas de nuestra tabla; en forma ascendente, descendente o en el estado original.***


```javaScript
 componentDidMount() {
    fetch(`http://localhost:8888/productos`)
      .then( res => res.json())
      .then( prds => this.setState({productos: prds, initialRows: [...prds]})); // [...array] clona el array
  }
   
    render() {
      ............
            <ReactDataGrid
              //..idem a los atributos de la rejilla simple...
                onGridSort={(sortColumn, sortDirection) =>
                this.setState({productos: sortProducts(this.state.productos, sortColumn, sortDirection, this.state.initialRows)})
                }
              //se llama cada vez que se hace clic en la celda del encabezado de la columna. 
            />
            ...
    }
    columns(){
        return [      
        {key: "_id",
        name: "ID",
        sortDescendingFirst: true
        // Para permitir que una columna se ordene en orden descendente primero
        },
        {
        key: "nombre",
        name: "Nombre"
        },
        {
        key: "precio",
        name: "Precio"
        }
        ].map(c=>({...c,...defaultColumnProperties}))
        }  
    }

  const defaultColumnProperties = {
    sortable: true,
    width: 320
    // Para hacer que una columna dada sea ordenable
  }

  const sortProducts = (rows, sortColumn, sortDirection, initialRows) => {
    console.log(initialRows);
    const comparer = (a, b) => {
      if (sortDirection === "ASC") {
        if (typeof a[sortColumn] === 'string') {
            return a[sortColumn].toUpperCase() > b[sortColumn].toUpperCase() ? 1 : -1;
        } 
        else {
          if(typeof a[sortColumn] == 'number') {
            return a[sortColumn] > b[sortColumn] ? 1 : -1;
          }
        }  
    } else{
        if (sortDirection === "DESC") {
          if (typeof a[sortColumn] === 'string') {
            return a[sortColumn].toUpperCase() < b[sortColumn].toUpperCase() ? 1 : -1;
          } 
          else {
            if(typeof a[sortColumn] === 'number'){                                    
              return a[sortColumn] < b[sortColumn] ? 1 : -1;
            }
          }
        }
      }  
    };
    return sortDirection === "NONE" ? [...initialRows] : rows.sort(comparer);
  };  
  
```


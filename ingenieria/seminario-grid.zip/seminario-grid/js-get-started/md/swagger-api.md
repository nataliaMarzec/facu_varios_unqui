# Swagger

- [swagger-jsdoc](https://www.npmjs.com/package/swagger-jsdoc)
Este módulo es para documentar su código existente, generando una especificación que luego pueda alimentar a otras herramientas Swagger, y no al revés.

**Instalar usando npm:**
```
$ npm install swagger-jsdoc --save
```
- [swagger-ui-express](https://www.npmjs.com/package/swagger-ui-express)
Este módulo le permite servir documentos API generados automáticamente por swagger-ui desde express, basados ​​en un archivo swagger.json. El resultado es documentación viva para su API alojada en un servidor a través de una ruta.


**Instalar usando npm:**
```
$ npm install swagger-ui-express --save
```

En el server.js importar:

```javascript
swaggerJSDoc=require('swagger-jsdoc');
swaggerUi=require('swagger-ui-express');
```

Luego creamos un archivo swagger.json, en este archivo definiremos como se ejecutan en la api de swagger los recursos de restfull.

```
* swagger.json

// Son etiquetas para especificar datos adicionales.
"tags":[
  {
    "name": "Ejemplo Clientes",
    "description": "Ejemplo Api de clientes"
  }

...
// Acá definimos una manera standar de enviar recursos a la red.
"consumes":[
  "application/json"
],

// Acá definimos una manera standar de recibir recursos de la red.
"produces":[
  "application/json"
],

// Aquí especificamos los paths y sus funciones básicas en el servicio restfull:

"paths":{
  "/clientes":{
    "get":{
      "tags":[
        "clientes"
      ],
      "summary": "Lista de todos los clientes en el sistema",

// Aquí especificamos la respuesta que esperamos del servidor:
      "responses":{
        "200":{
          "description": "Ok",
             "schema":{
                "type":"array",                
                "items":{
// Aquí hacemos referencia a lo que nos devuelve el servidor:
                  "$ref":"#/definitions/clientes"
                }
              }
        }  
      }
    },
    "post":{
      "tags":[
        "clientes"
      ],
    "summary":"Ejemplo Agrega un cliente al listado",
    "description":"Ejemplo Objeto cliente",
// Acá agregamos el "body" dentro de "parameters" para insertar un objeto json:
    "parameters":[
      { "name":"Cliente",
        "in":"body",
        "required":true,
        "schema":{
          "$ref": "#/definitions/clienteSinId"
              }
      }
    ],
      
      "produces": [
        "application/json"
      ],
      "responses":{
        "204":{
          "description":"Ok",
          "schema":{
            "$ref": "#/definitions/cliente"
          }
        }
      }
    },
    "put":{
      "summary": "Edita un cliente de la lista",
      "tags": [
          "cliente"
      ],
      "parameters": [
        {
            "in": "body",
            "name": "body",
            "required": true,
            "description": "Cliente con modificaciones",
            "schema": {
                "$ref": "#/definitions/cliente"
            }
        }
      ],
// Define el cuerpo HTTP esperado en formato json
      "requestBody": {
          "description": "Objeto cliente",
          "required": true,
          "content": {
              "application/json": {
                  "schema": {
                      "$ref": "#/definitions/cliente"
                  }
              }
          }
      },
      
      "responses": {
          "204": {
              "description": "OK",
              "schema":{
                "$ref":"#/definitions/cliente"
              }
          },
          "404": {
            "description": "No se puede encontrar el cliente."
        }
      }
    }
  },  
// El parámetro entre llaves es necesario porque es parte de la estructura.
  "/clientes/{id}":{
   
      "delete":{
// Aca definimos los parámetros del objeto en sí. En este caso es necesario pasar el id para poder borrar ese objeto en particular.
        "parameters": [
        {
            "in": "path",
            "name": "id",
            "required": true,
            "description": "Borrado de cliente",
            "produces":["application/json"],
            "schema": {
                "$ref": "#/definitions/id"
            }
        }
    ],

      "summary":"Borra el cliente correspondiente al Id",
      "responses":{
        "204":{
          "description": "Ok",
          "schema":{
            "ref":"#/definitions/cliente"
          }
        }
      }
    }
  },

```

```
// Aca se definen los objetos para contener los tipos de datos producidos y consumidos por las operaciones.

"definitions":{
// Acá van las definiciones específicas para todos los objetos, ejemplo id.
    "id": {
        "properties": {
            "uuid": {
                "type": "string"
            }
        }
    },
// A partir de esta línea definimos uno a uno todos los objetos con sus propiedades, ej cliente productos,etc.

    "cliente":{
      "type":"object",
      "properties":{
        "id":{
          "required":true,
          "example":32
        } ,
        "nombre":{
          "required": true,
          "type":"string",
          "example":"Martina"
        },
        "apellido":{
          "required": true,
          "type":"string",
          "example":"Ramirez"
        }
      }
    },
    "clienteSinId":{
      "type":"object",
      "properties":{
        
        "nombre":{
          "required": true,
          "type":"string",
          "example":"Martina"
        },
        "apellido":{
          "required": true,
          "type":"string",
          "example":"Ramirez"
        }
      }
    },
    "clientes": {
      "type": "object",
      "properties": {
          "clientes": {
              "type": "object",
              "additionalProperties": {
                  "$ref": "#/definitions/cliente"
              }
          }
        }
    }

  }  
 }

```

Volver al server.js:

```javascript

// Importa el swaggerDefinition 
const swaggerDefinition =require("./swagger.json");

const options ={
// ruta a los ducumentos API 
  swaggerDefinition , apis: ['home'],
};
// Inicialización del swagger-jsdoc
const swaggerSpec= swaggerJSDoc(options);

...

function init() {
...
// Agrega la ruta '/api-docs' para levantar el servicio
server.use('/api-docs',swaggerUi.serve, swaggerUi.setup(swaggerSpec));

...

```
[Para navegar en swagger cliqueá aquí](http://localhost:3000/api-docs)


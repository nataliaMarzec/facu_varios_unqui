  

### MongoHome.js y Server.js  - Consulta Generica 

La idea es que podamos hacer varias consultas de manera mas sencilla a Mongo

En server.js vamos hacer un IF:
```javascript
  if (req.query.consulta) {
        console.log("Query:" + req.query.consulta) 
        var Consulta = (req.query.consulta)
        query = rsqlMongoDB (Consulta)
  } 
```
Lo que estamos haciando ahí es que req.query.consulta contiene una consulta genérica. 
Así se usa en el browser: (localhost:8888/productos?consulta=nombre=="ejm")
si recibe `(nombre=="ejm")`
rsqlMongoDB lo agarra y me lo tranforma en una query que entiende mongo y quedaría así,
`{"nombre": "ejm"}`

Esto que sigue lo que hace es traerme todos los Clientes o Productos
```javascript 
  home = homes[req.params.type]

    home.find(query,
      (allObjects) => {
        res.json(allObjects) 
        res.end()
      }) 
```

### MongoHome.js    

ALL ya no lo usamos lo remplasamos por el FIND

```javascript
find(query, callback) {
        this.persistentCollection.find(query).toArray( (error, result)=>{
            if(error) throw error
            callback(result)
        })
    }
```

### La Documentacion 

Otras operaciones compatibles
```
Igual a: ==
No es igual a:! =
Menos de: = lt =
Menor o igual que: = le =
Mayor que: = gt =
Mayor o igual que: = ge =
En: = en =
No dentro: = fuera =
```
[MongoDb](https://github.com/Fizcko/rsql-mongodb).

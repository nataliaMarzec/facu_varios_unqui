### Auth0

Esta aplicación usa autenticación a través de los servicios que ofrece [Auth0](https://auth0.com/).
A continuación se detalla los pasos que deben realizarse para poder incorporarlo al proyecto.

#### Creación de usuario en Auth0

Es necesario registrarse en Auth0, por varios motivos pero lo que más nos interesa es poder armar un Login fácil, rápido y seguro.
Una vez registrado tendremos que crear una APP en la solapa Applicatios de Auth0

![](https://user-images.githubusercontent.com/32805369/65730650-e699ca00-e098-11e9-9266-7e75eceb0276.png)

En esta sección vamos a configurar nuestra aplicación, ésta contará con ciertos parametros autogenerados que precisaremos más adelante como el **Domain** y el **Client ID**.

### Configuración de Auth0
#### Configurar Callback URLs

Una Callback URL es una URL en tu aplicación donde Auth0 redirige al usuario después de que se haya autenticado. En otras palabras es la página a la que iremos una vez hayamos iniciado sesión.

Nos iremos a aplicaciones -> settings

![](https://user-images.githubusercontent.com/32805369/67054334-9a332e80-f11a-11e9-8a0c-a85b66929e64.png)

Una vez aquí vamos a Allowed Callback URLs y escribiremos la URL a la que nos redireccionará una vez que nos hayamos logueado.

![](https://user-images.githubusercontent.com/32805369/67055156-555cc700-f11d-11e9-9c23-4ceaa8b1b82c.png)

#### Configuar Logouts URLs

Continuamos con la configuración del Logouts URLs, es la URL a la que nos redireccionará una vez hayamos cerrado sesión.

![](https://user-images.githubusercontent.com/32805369/67055227-9ce35300-f11d-11e9-8e3c-78c56cf7a1da.png)


#### Instalar dependecias

Si se quiere agregar solo la dependecia de Auth0, se debe ejecutar el siguiente link en el /frontend

``` javascript
npm install react-router-dom @auth0/auth0-spa-js
```

O si queremos utilizar la página de Login que nos ofrece Auth0 podemos agregar estas dependencias al package.json y luego hacer npm install

``` javascript
"dependencies": {
    "bootstrap": "^4.3.1",
    "@auth0/auth0-spa-js": "^1.0.2",
    "@fortawesome/fontawesome-svg-core": "^1.2.17",
    "@fortawesome/free-solid-svg-icons": "^5.8.1",
    "@fortawesome/react-fontawesome": "^0.1.4",
    "express": "^4.16.4",
    "highlight.js": "^9.15.6",
    "morgan": "^1.9.1",
    "react": "^16.8.6",
    "react-dom": "^16.8.6",
    "react-router-dom": "^5.0.0",
    "react-scripts": "3.0.1",
    "reactstrap": "^8.0.0"
  }
```
  
  
 #### Creación de archivos de configuración
 
 En esta etapa vamos a crear los archivos de configuración necesarios para implementar Auth0 al proyecto.
 
 * Creamos dentro de la carpeta src un nuevo archivo llamado `react-auth0-spa.js`
  
``` javascript
// src/react-auth0-spa.js
import React, { useState, useEffect, useContext } from "react";
import createAuth0Client from "@auth0/auth0-spa-js";

const DEFAULT_REDIRECT_CALLBACK = () =>
  window.history.replaceState({}, document.title, window.location.pathname);

export const Auth0Context = React.createContext();
export const useAuth0 = () => useContext(Auth0Context);
export const Auth0Provider = ({
  children,
  onRedirectCallback = DEFAULT_REDIRECT_CALLBACK,
  ...initOptions
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState();
  const [user, setUser] = useState();
  const [auth0Client, setAuth0] = useState();
  const [loading, setLoading] = useState(true);
  const [popupOpen, setPopupOpen] = useState(false);

  useEffect(() => {
    const initAuth0 = async () => {
      const auth0FromHook = await createAuth0Client(initOptions);
      setAuth0(auth0FromHook);

      if (window.location.search.includes("code=")) {
        const { appState } = await auth0FromHook.handleRedirectCallback();
        onRedirectCallback(appState);
      }

      const isAuthenticated = await auth0FromHook.isAuthenticated();

      setIsAuthenticated(isAuthenticated);

      if (isAuthenticated) {
        const user = await auth0FromHook.getUser();
        setUser(user);
      }

      setLoading(false);
    };
    initAuth0();
    // eslint-disable-next-line
  }, []);

  const loginWithPopup = async (params = {}) => {
    setPopupOpen(true);
    try {
      await auth0Client.loginWithPopup(params);
    } catch (error) {
      console.error(error);
    } finally {
      setPopupOpen(false);
    }
    const user = await auth0Client.getUser();
    setUser(user);
    setIsAuthenticated(true);
  };

  const handleRedirectCallback = async () => {
    setLoading(true);
    await auth0Client.handleRedirectCallback();
    const user = await auth0Client.getUser();
    setLoading(false);
    setIsAuthenticated(true);
    setUser(user);
  };
  return (
    <Auth0Context.Provider
      value={{
        isAuthenticated,
        user,
        loading,
        popupOpen,
        loginWithPopup,
        handleRedirectCallback,
        getIdTokenClaims: (...p) => auth0Client.getIdTokenClaims(...p),
        loginWithRedirect: (...p) => auth0Client.loginWithRedirect(...p),
        getTokenSilently: (...p) => auth0Client.getTokenSilently(...p),
        getTokenWithPopup: (...p) => auth0Client.getTokenWithPopup(...p),
        logout: (...p) => auth0Client.logout(...p)
      }}
    >
      {children}
    </Auth0Context.Provider>
  );
};
```

Este archivo nos sirve para utilizarlo más adelante, nos brinda ciertas utilidades de información y operaciones sobre el usuario en cuestión, como
por ejemplo permitir al usuario iniciar sesión, cerrarla y saber el estado de la misma.


* Crear el componente NavBar

Crear una nueva carpeta dentro de `src` llamada `components`, si es que ya no la tienes creada. Luego dentro de la nueva carpeta crear un archivo llamado
`NavBar.js`

``` javascript
// src/components/NavBar.js

import React from "react";
import { useAuth0 } from "../react-auth0-spa";

const NavBar = () => {
  const { isAuthenticated, loginWithRedirect, logout } = useAuth0();

  return (
    <div>
      {!isAuthenticated && (
        <button
          onClick={() =>
            loginWithRedirect({})
          }
        >
          Log in
        </button>
      )}

      {isAuthenticated && <button onClick={() => logout()}>Log out</button>}
    </div>
  );
};

export default NavBar;
```

Este componente presenta dos botones, para iniciar y cerrar sesión, dependiendo de si el usuario está autenticado actualmente.

* Integrar el SDK

Debemos integrar el SDK(react-auth0-spa.js) al index.js para que el sistema de autenticación funcione correctamente.

Abrir el archivo que se encuentra en `src/index.js` y reemplazar el siguiente contenido 

``` javascript
// src/index.js

import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import * as serviceWorker from "./serviceWorker";
import { Auth0Provider } from "./react-auth0-wrapper";
import config from "./auth_config.json";
import 'bootstrap/dist/css/bootstrap.css';

// A function that routes the user to the right place
// after login
const onRedirectCallback = appState => {
  window.history.replaceState(
    {},
    document.title,
    appState && appState.targetUrl
      ? appState.targetUrl
      : window.location.pathname
  );
};

ReactDOM.render(
  <Auth0Provider
    domain={config.domain}
    client_id={config.clientId}
    redirect_uri={window.location.origin + "/clientes"}
    onRedirectCallback={onRedirectCallback}
>
    <App />
  </Auth0Provider>,
  document.getElementById("root")
);

serviceWorker.unregister();
```

En este archivo se especifican los detalles sobre el dominio Auth0 y la identificación del cliente. 
También se encuentra la función onRedirectCallback, que enruta al usuario al lugar correcto una vez que ha iniciado sesión. 

* Crearemos dentro de la carpeta `src` un nuevo archivo nombrado `auth_config.json`, este contendra el Domain y el ClientId de nuestra aplicación que
  creamos en Auth0. Para obtener esta información dirigiremos a nuestro panel de Auth0, en la parte de aplicaciónes, el nombre de nuestra aplicación y settings.

``` javascript
{
    "domain": "dev-q25jqk3m.auth0.com",
    "clientId": "Tge6igDbnuEcFFnoTTWyTEXTQdQBxE6P"
}
```

* Ahora debemos agregar un archivo más de configuración para Auth0, nuevamente dentro de la carpeta `src` crearemos un archivo llamado `react-auth0-wrapper.js`
  con el siguiente contenido

``` javascript
// src/react-auth0-wrapper.js
import React, { useState, useEffect, useContext } from "react";
import createAuth0Client from "@auth0/auth0-spa-js";

const DEFAULT_REDIRECT_CALLBACK = () =>
  window.history.replaceState({}, document.title, window.location.pathname);

export const Auth0Context = React.createContext();
export const useAuth0 = () => useContext(Auth0Context);
export const Auth0Provider = ({
  children,
  onRedirectCallback = DEFAULT_REDIRECT_CALLBACK,
  ...initOptions
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState();
  const [user, setUser] = useState();
  const [auth0Client, setAuth0] = useState();
  const [loading, setLoading] = useState(true);
  const [popupOpen, setPopupOpen] = useState(false);

  useEffect(() => {
    const initAuth0 = async () => {
      const auth0FromHook = await createAuth0Client(initOptions);
      setAuth0(auth0FromHook);

      if (window.location.search.includes("code=")) {
        const { appState } = await auth0FromHook.handleRedirectCallback();
        onRedirectCallback(appState);
      }

      const isAuthenticated = await auth0FromHook.isAuthenticated();

      setIsAuthenticated(isAuthenticated);

      if (isAuthenticated) {
        const user = await auth0FromHook.getUser();
        setUser(user);
      }

      setLoading(false);
    };
    initAuth0();
    // eslint-disable-next-line
  }, []);

  const loginWithPopup = async (params = {}) => {
    setPopupOpen(true);
    try {
      await auth0Client.loginWithPopup(params);
    } catch (error) {
      console.error(error);
    } finally {
      setPopupOpen(false);
    }
    const user = await auth0Client.getUser();
    setUser(user);
    setIsAuthenticated(true);
  };

  const handleRedirectCallback = async () => {
    setLoading(true);
    await auth0Client.handleRedirectCallback();
    const user = await auth0Client.getUser();
    setLoading(false);
    setIsAuthenticated(true);
    setUser(user);
  };
  return (
    <Auth0Context.Provider
      value={{
        isAuthenticated,
        user,
        loading,
        popupOpen,
        loginWithPopup,
        handleRedirectCallback,
        getIdTokenClaims: (...p) => auth0Client.getIdTokenClaims(...p),
        loginWithRedirect: (...p) => auth0Client.loginWithRedirect(...p),
        getTokenSilently: (...p) => auth0Client.getTokenSilently(...p),
        getTokenWithPopup: (...p) => auth0Client.getTokenWithPopup(...p),
        logout: (...p) => auth0Client.logout(...p)
      }}
    >
      {children}
    </Auth0Context.Provider>
  );
};
```

* Lo siguiente será agregar código a nuestro `App.js` que se encuentra dentro de `src`

``` javascript
// src/App.js

import React from "react";
import NavBar from "./components/NavBar";
import { useAuth0 } from "./react-auth0-spa";

function App() {
  const { loading } = useAuth0();

  if (loading) {
    return (
      <div>Loading...</div>
    );
  }

  return (
    <div className="App">
      <header>
        <NavBar />
      </header>
    </div>
  );
}

export default App;
```

* En este punto ya tendrán el proyecto integrado con Auth0, para más información pueden ir a su panel -> aplications -> quick start 
o para más información visitar a [Documentación](https://auth0.com/docs/api/authentication#base-url)

## Herramienta necesaria
Se necesita instalar Winston en el projecto con la linea. 

 ```
 npm install winston --save
 ```

Winston es un middleware utilizado 
Se crea un archivo logger.js en el cual se crea y define el logger.

```javascript
const winston = require('winston')
const consoleTransport = new winston.transports.Console()
const { combine, timestamp, printf } = winston.format;

const myFormat = printf(({ level, message, timestamp }) => {
    return `${timestamp} ${level}: ${message}`;
  });

const myWinstonOptions = {
    format: combine(
        timestamp(),
        myFormat
      ),
    level: 'debug',
    transports: [consoleTransport,
        new winston.transports.File({ filename: 'error.log', level: 'error' }),
        new winston.transports.File({ filename: 'info.log', level: 'info' }),
        new winston.transports.File({ filename: 'combined.log' })
    ]
}
const logger = new winston.createLogger(myWinstonOptions)

module.exports = logger
```

Aqui se define el logger, el formato que va a tener cada log y donde se guardan los logs.


En el archivo server.js se llama al logger.
```javascript
log = require("./src/logger");
```
Se crea una funcion que inicia el logger.
```javascript
function init() {
  var server = express();
  server.use(bodyParser.json());

  server.use((req, res, next) => {
      log.info(req.url)
      next()
  })

  server.use((err, req, res, next) => {
    log.error(err)
    next()
  })
```

Se llama al log previamente definido en el archivo con log.info o log error, mandando el mensaje que se quiere que guarde.

```javascript
 server.use("(/:type/*)|(/:type)", (req, res, next) => {
      if (!homes[req.params.type]) {
        log.error(`home de ${req.params.type} no existe` );  
      }
      else {
        log.info(` home de ${req.params.type} si existe ` );
        next()
      }
  })
```

Para mas informacion, vea la documentacion de Winston https://github.com/winstonjs/winston